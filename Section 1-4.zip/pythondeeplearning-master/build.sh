#!/usr/bin/env bash
docker build --tag pythondeeplearning .
