'''
Generate a new random MIDI file based on a previously learned machine learning model.
'''

class SeededSong:
    def __init__(self, model_file_name):
        pass

    def save(self, midi_file_name):
        pass